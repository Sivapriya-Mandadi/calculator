let data = [{
        "name": "John Smith",
        "age": 35,
        "country": "USA",
        "phone": "+1-555-0123",
        "email": "john.smith@email.com"
    },
    {
        "name": "Emily Johnson",
        "age": 28,
        "country": "Canada",
        "phone": "+1-555-0124",
        "email": "emily.johnson@email.com"
    },
    {
        "name": "Michael Williams",
        "age": 42,
        "country": "UK",
        "phone": "+44-555-0125",
        "email": "michael.williams@email.com"
    },
    {
        "name": "Sophia Brown",
        "age": 19,
        "country": "Australia",
        "phone": "+61-555-0126",
        "email": "sophia.brown@email.com"
    },
    {
        "name": "William Jones",
        "age": 63,
        "country": "USA",
        "phone": "+1-555-0127",
        "email": "william.jones@email.com"
    },
    {
        "name": "Emma Garcia",
        "age": 24,
        "country": "Spain",
        "phone": "+34-555-0128",
        "email": "emma.garcia@email.com"
    },
    {
        "name": "Daniel Rodriguez",
        "age": 31,
        "country": "Mexico",
        "phone": "+52-555-0129",
        "email": "daniel.rodriguez@email.com"
    },
    {
        "name": "Olivia Martinez",
        "age": 27,
        "country": "Brazil",
        "phone": "+55-555-0130",
        "email": "olivia.martinez@email.com"
    },
    {
        "name": "Matthew Hernandez",
        "age": 38,
        "country": "USA",
        "phone": "+1-555-0131",
        "email": "matthew.hernandez@email.com"
    },
    {
        "name": "Ava Gonzalez",
        "age": 22,
        "country": "Chile",
        "phone": "+56-555-0132",
        "email": "ava.gonzalez@email.com"
    },
    {
        "name": "David Perez",
        "age": 49,
        "country": "Argentina",
        "phone": "+54-555-0133",
        "email": "david.perez@email.com"
    },
    {
        "name": "Isabella Sanchez",
        "age": 18,
        "country": "Colombia",
        "phone": "+57-555-0134",
        "email": "isabella.sanchez@email.com"
    },
    {
        "name": "Joseph Ramirez",
        "age": 33,
        "country": "USA",
        "phone": "+1-555-0135",
        "email": "joseph.ramirez@email.com"
    },
    {
        "name": "Mia Torres",
        "age": 26,
        "country": "Mexico",
        "phone": "+52-555-0136",
        "email": "mia.torres@email.com"
    },
    {
        "name": "Andrew Rivera",
        "age": 41,
        "country": "USA",
        "phone": "+1-555-0137",
        "email": "andrew.rivera@email.com"
    },
    {
        "name": "Abigail Flores",
        "age": 29,
        "country": "Peru",
        "phone": "+51-555-0138",
        "email": "abigail.flores@email.com"
    },
    {
        "name": "Joshua Gomez",
        "age": 36,
        "country": "USA",
        "phone": "+1-555-0139",
        "email": "joshua.gomez@email.com"
    },
    {
        "name": "Emily Diaz",
        "age": 23,
        "country": "Spain",
        "phone": "+34-555-0140",
        "email": "emily.diaz@email.com"
    },
    {
        "name": "Christopher Gutierrez",
        "age": 47,
        "country": "USA",
        "phone": "+1-555-0141",
        "email": "christopher.gutierrez@email.com"
    },
    {
        "name": "Harper Morales",
        "age": 20,
        "country": "Mexico",
        "phone": "+52-555-0142",
        "email": "harper.morales@email.com"
    },
    {
        "name": "Madison Martinez",
        "age": 32,
        "country": "USA",
        "phone": "+1-555-0143",
        "email": "madison.martinez@email.com"
    }
];



// Function to perform search
function search() {
    const searchTerm = (document.getElementById('searchInput') || {}).value?.trim().toLowerCase();

    if (!searchTerm) {
        console.error('Search term is empty.');
        return;
    }

    const searchResults = document.getElementById('searchResults');

    // Clear previous search results
    searchResults.innerHTML = '';

    // Filter data based on search term
    const filteredData = data.filter(item =>
        item.name.toLowerCase().includes(searchTerm)
    );

    // Display search results
    if (filteredData.length > 0) {
        filteredData.forEach(item => {
            const resultDiv = document.createElement('div');
            resultDiv.classList.add('result');
            resultDiv.innerHTML = `
                <h3>Name: ${item.name}</h3>
                <p>Age: ${item.age}</p>
                <p>Country: ${item.country}</p>
                <p>Phone: ${item.phone}</p>
                <p>Email: ${item.email}</p>
            `;
            searchResults.appendChild(resultDiv);
        });
    } else {
        searchResults.innerHTML = '<p>No results found.</p>';
    }
}